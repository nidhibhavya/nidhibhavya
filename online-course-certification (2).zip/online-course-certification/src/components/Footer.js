import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>&copy; 2024 Online Course Certification Management System</p>
    </footer>
  );
};

export default Footer;
