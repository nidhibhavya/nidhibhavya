import React from 'react';
import { Link } from 'react-router-dom';

const Courses = () => {
  return (
    <div className="courses">
      <h1>All Courses</h1>
      <div className="course-list">
        <div className="course-item">
          <h3>Course Title 1</h3>
          <p>Short description...</p>
          <Link to="/courses/1">View Details</Link>
        </div>
        <div className="course-item">
          <h3>Course Title 2</h3>
          <p>Short description...</p>
          <Link to="/courses/2">View Details</Link>
        </div>
      </div>
    </div>
  );
};

export default Courses;
