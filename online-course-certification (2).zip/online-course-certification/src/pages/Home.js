import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="home">
      <header className="hero-section">
        <h1>Achieve Your Learning Goals with Certified Courses!</h1>
        <input type="text" placeholder="Search courses..." />
        <Link to="/courses" className="button">Browse Courses</Link>
      </header>
      
      <section className="featured-courses">
        <h2>Featured Courses</h2>
        <div className="course-grid">
          <div className="course-card">
            <h3>Course Title 1</h3>
            <p>Short description of the course.</p>
            <Link to="/courses/1" className="learn-more">Learn More</Link>
          </div>
          <div className="course-card">
            <h3>Course Title 2</h3>
            <p>Short description of the course.</p>
            <Link to="/courses/2" className="learn-more">Learn More</Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
